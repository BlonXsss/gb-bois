// --- Robot number generator for contact form ---
function generateRobotNumber() {
    return Math.floor(1000 + Math.random() * 9000).toString();
}

function setupRobotCheck() {
    const numberSpan = document.getElementById('robot-number');
    const input = document.getElementById('robot-input');
    const form = document.getElementById('contact-form');
    if (!numberSpan || !input || !form) return;
    let currentNumber = generateRobotNumber();
    numberSpan.textContent = currentNumber;
    input.value = '';
    form.addEventListener('submit', function(e) {
        if (input.value !== currentNumber) {
            e.preventDefault();
            alert('Veuillez recopier correctement le nombre pour prouver que vous n’êtes pas un robot.');
            currentNumber = generateRobotNumber();
            numberSpan.textContent = currentNumber;
            input.value = '';
        }
    });
}

document.addEventListener('DOMContentLoaded', function () {
    const slides = document.querySelectorAll('.carousel-slide');
    let current = 0;
    const interval = 6000; // 6 seconds

    function showSlide(idx) {
        slides.forEach((slide, i) => {
            slide.classList.toggle('active', i === idx);
        });
    }

    function nextSlide() {
        current = (current + 1) % slides.length;
        showSlide(current);
    }

    setInterval(nextSlide, interval);

    // --- Galerie slider code ---
    const galerieTrack = document.querySelector('.galerie-track');
    const galerieSlides = Array.from(document.querySelectorAll('.galerie-slide'));
    const galerieDotsContainer = document.querySelector('.galerie-dots');
    const visibleCount = 3;
    const total = galerieSlides.length;
    let galerieIndex = 0;
    let galerieInterval = null;
    const dotCount = total - visibleCount + 1;

    function updateGalerie() {
        galerieSlides.forEach((slide, i) => {
            slide.classList.remove('center');
            slide.style.opacity = '0.6';
            slide.style.transform = 'scale(0.85)';
        });
        // Center slide
        const centerIdx = galerieIndex + 1;
        if (galerieSlides[centerIdx]) {
            galerieSlides[centerIdx].classList.add('center');
            galerieSlides[centerIdx].style.opacity = '1';
            galerieSlides[centerIdx].style.transform = 'scale(1.12)';
        }
        // Move track
        const slideWidth = galerieSlides[0].offsetWidth;
        galerieTrack.style.transform = `translateX(-${galerieIndex * (slideWidth + 0)}px)`;
        // Update dots
        Array.from(galerieDotsContainer.children).forEach((dot, i) => {
            dot.classList.toggle('active', i === galerieIndex);
        });
    }

    function nextGalerie() {
        galerieIndex = (galerieIndex + 1) % dotCount;
        updateGalerie();
    }

    function goToGalerie(idx) {
        galerieIndex = idx;
        updateGalerie();
    }

    // Create dots
    for (let i = 0; i < dotCount; i++) {
        const dot = document.createElement('div');
        dot.className = 'galerie-dot';
        dot.addEventListener('click', () => goToGalerie(i));
        galerieDotsContainer.appendChild(dot);
    }

    updateGalerie();
    galerieInterval = setInterval(nextGalerie, 4000);

    // Pause on hover
    galerieTrack.addEventListener('mouseenter', () => clearInterval(galerieInterval));
    galerieTrack.addEventListener('mouseleave', () => {
        galerieInterval = setInterval(nextGalerie, 4000);
    });

    const prevBtn = document.querySelector('.galerie-prev');
    const nextBtn = document.querySelector('.galerie-next');

    function prevGalerie() {
        galerieIndex = (galerieIndex - 1 + dotCount) % dotCount;
        updateGalerie();
    }

    if (prevBtn && nextBtn) {
        prevBtn.addEventListener('click', () => {
            prevGalerie();
            clearInterval(galerieInterval);
            galerieInterval = setInterval(nextGalerie, 4000);
        });
        nextBtn.addEventListener('click', () => {
            nextGalerie();
            clearInterval(galerieInterval);
            galerieInterval = setInterval(nextGalerie, 4000);
        });
    }
    setupRobotCheck();

    // Scroll fade-in animation
    const fadeEls = document.querySelectorAll('.scroll-fade-in');
    const observer = new window.IntersectionObserver((entries, obs) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('fade-in-visible');
                obs.unobserve(entry.target);
            }
        });
    }, { threshold: 0.15 });
    fadeEls.forEach(el => observer.observe(el));
}); 